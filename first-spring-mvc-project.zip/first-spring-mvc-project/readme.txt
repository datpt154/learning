Assuming that you are in directory first-spring-mvc-project, here're the steps to build and launch application:
1. configure setenv.bat
2. config maven (..\tools\maven\conf\settings.xml)
3. cd web-war
4. > startserver.bat \r